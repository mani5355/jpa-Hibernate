package com.cg.author.dao;

import java.util.List;

import com.cg.author.entities.Author;
import com.cg.author.exception.AuthorException;

public interface IAuthorDAO {
	public int addAuthor(Author author) throws AuthorException;
	public Author deleteAuthor(int id) throws AuthorException;
	public Author findAuthor(int id) throws AuthorException;
	public List<Author> displayAuthor() throws AuthorException;
	public Author updateAuthor(int id, String mobile) throws AuthorException;

}
