package com.cg.author.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.author.entities.Author;
import com.cg.author.exception.AuthorException;

public class AuthorDAOImpl implements IAuthorDAO {
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em=emf.createEntityManager();
	Author author=new Author();

	@Override
	public int addAuthor(Author author) throws AuthorException {
		em.getTransaction().begin();
		em.persist(author);
		em.getTransaction().commit();
			return author.getId();
	}

	@Override
	public Author deleteAuthor(int id) throws AuthorException {
		em.getTransaction().begin();
		author = em.find(Author.class, id);
		if(author==null)
		{
			return null;
		}
		else
		{
			em.remove(author);
			em.getTransaction().commit();
			return author;
		
		}
		
		
	}

	@Override
	public Author findAuthor(int id) throws AuthorException {
		em.getTransaction().begin();
		author = em.find(Author.class, id);
		if(author==null)
		{
			return null;
		}
		else
		{
			em.getTransaction().commit();
			return author;
		
		}
		
		
	}

	@Override
	public List<Author> displayAuthor() throws AuthorException {
		em.getTransaction().begin();
		TypedQuery<Author> qry = em.createNamedQuery("view", Author.class);
		List<Author> list=qry.getResultList();
		if(list.equals(null))
		{
			return null;
		}
		else{
	    return list;
		}	
		}

	@Override
	public Author updateAuthor(int id, String mobile) throws AuthorException {
		
		em.getTransaction().begin();
		author = em.find(Author.class, id);
		if(author==null)
		{
			return null;
		}
		else
		{
			author.setMobile(mobile);
			em.getTransaction().commit();
			return author;
		
		}
	}
}
