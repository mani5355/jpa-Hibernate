package com.cg.author.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="authors")
@NamedQuery(name="view" ,query="from Author")
public class Author {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="author_id")
	private int id;
	
	 @Column(name="author_fName" ,length=10)
	 private String fName;
	 
	 @Column(name="author_mName",length=10)
	 private String mName;
	 
	 @Column(name="author_lName",length=10)
	 private String lName;
	 
	 @Column(name="author_mobile",length=10)
	 private String mobile;
	 
	public Author() {
		super();
	}
	public Author(int id, String fName, String mName, String lName,
			String mobile) {
		super();
		this.id = id;
		this.fName = fName;
		this.mName = mName;
		this.lName = lName;
		this.mobile = mobile;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getmName() {
		return mName;
	}
	public void setmName(String mName) {
		this.mName = mName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	@Override
	public String toString() {
		return "Author [id=" + id + ", fName=" + fName + ", mName=" + mName
				+ ", lName=" + lName + ", mobile=" + mobile + "]";
	}
	
	

}
