package com.cg.author.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.author.entities.Author;
import com.cg.author.exception.AuthorException;
import com.cg.author.service.AuthorServiceImpl;
import com.cg.author.service.IAuthorService;

public class Client {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String fName, mName, lName, mobile;
		IAuthorService authorService = new AuthorServiceImpl();
		Author author = new Author();
		System.out.println("1.ADD");
		System.out.println("2.DELETE");
		System.out.println("3.FIND");
		System.out.println("4.SHOWALL");
		System.out.println("5.EXIT");
		System.out.println("type 1, 2 ,3 ,4 or 5");
		int ch = sc.nextInt();
		         sc.nextLine();
		switch(ch)
		{
		case 1:
		System.out.println("enter first name");
		fName=sc.nextLine();
		System.out.println("enter middle name");
		mName=sc.nextLine();
		System.out.println("enter last name");
		lName=sc.nextLine();
		System.out.println("enter mobile number");
		mobile=sc.nextLine();
		author.setfName(fName);
		author.setmName(mName);
		author.setlName(lName);
		author.setMobile(mobile);
		try {
			int flag=authorService.addAuthor(author);
			if(flag>0)
			{
				System.out.println("Successfully inserted for id = " +flag);
			}
			else
			{
				System.out.println("error while inserting");
			}
		} catch (AuthorException e) {
			System.out.println("in add mtd"+e.getMessage());
		}
		break;
		case 2:
			System.out.println("enter id to be deleted");
			int id=sc.nextInt();
			try {
				author = authorService.deleteAuthor(id);
				if(author.equals(null))
				{
					System.out.println("error while deletion");
				}
				else{
				System.out.println("deleted successfully");
				System.out.println(author.getId()+" "+author.getfName()+" "+author.getmName()+" "+author.getlName()+" "+author.getMobile());
				}
			} catch (AuthorException e) {
				System.out.println("in del mtd"+e.getMessage());
			}
			break;
		case 3:
			System.out.println("enter id to be find");
			int idd=sc.nextInt();
			try {
				author = authorService.deleteAuthor(idd);
				if(author.equals(null))
				{
					System.out.println("cant find");
				}
				else{
				System.out.println("found");
				System.out.println(author.getId()+" "+author.getfName()+" "+author.getmName()+" "+author.getlName()+" "+author.getMobile());
				}
			} catch (AuthorException e) {
				System.out.println("in find mtd"+e.getMessage());
			}
			break;
		case 4:
			List<Author> list = new ArrayList<Author>();
			try {
				list=authorService.displayAuthor();
				
				if(list.equals(null))
				{
					System.out.println("b");
					System.out.println("not showing anything");
				}else{
				for(Author at : list )
					
				{	
					System.out.println(at);
					System.out.println(at.getId()+" "+at.getfName()+" "+at.getmName()+" "+at.getlName()+" "+at.getMobile());
				}
				}
			} catch (AuthorException e) {
				System.out.println("d");
				System.out.println("in display mtd"+e.getMessage());
			}
			break;
		case 5:
			System.out.println("enter id to be updated");
			int iddd=sc.nextInt();
			         sc.nextLine();
			 System.out.println("enter new mobile");       
			 String mob=sc.nextLine();        
			try {
				author = authorService.updateAuthor(iddd, mob);
				if(author.equals(null))
				{
					System.out.println("error while deletion");
				}
				else{
				System.out.println("updated successfully");
				System.out.println(author.getId()+" "+author.getfName()+" "+author.getmName()+" "+author.getlName()+" "+author.getMobile());
				}
			} catch (AuthorException e) {
				System.out.println("in del mtd"+e.getMessage());
			}
			break;
		
		
		
		
		}
		sc.close();
	}

}
