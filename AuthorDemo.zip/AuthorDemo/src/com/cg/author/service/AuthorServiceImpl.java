package com.cg.author.service;

import java.util.List;

import com.cg.author.dao.AuthorDAOImpl;
import com.cg.author.dao.IAuthorDAO;
import com.cg.author.entities.Author;
import com.cg.author.exception.AuthorException;

public class AuthorServiceImpl implements IAuthorService {
	IAuthorDAO dao = new AuthorDAOImpl();

	@Override
	public int addAuthor(Author author) throws AuthorException {

		return dao.addAuthor(author);
	}

	@Override
	public Author deleteAuthor(int id) throws AuthorException {
		
		return dao.deleteAuthor(id);
	}

	@Override
	public Author findAuthor(int id) throws AuthorException {
	
		return dao.findAuthor(id);
	}

	@Override
	public List<Author> displayAuthor() throws AuthorException {
		
		return dao.displayAuthor();
	}

	@Override
	public Author updateAuthor(int id, String mobile) throws AuthorException {
		// TODO Auto-generated method stub
		return dao.updateAuthor(id, mobile);
	}

}
